angular.module('customerApp', [])
  .controller('CustomerController', function($scope) {

	var customers = [
        { firstName: "Raj", lastName: "Joseph", age: "28", cityAndstate: "Houston,TX", email:"ajdjks@gmail.com"},
        { firstName: "Kyoseok", lastName: "Hwang", age: "40", cityAndstate: "Houston,TX", email: "good@gmail.com" }
	];
	
	$scope.addThisCustomer = function() {
		$scope.customers.push({firstName:$scope.firstName, lastName:$scope.lastName, age:$scope.age, cityAndstate:$scope.cityAndstate, email:$scope.email});
		//firstName = '';
	};	

	$scope.deleteThisCustomer = function() {
		$scope.customers.pop({firstName:$scope.firstName, lastName:$scope.lastName, age:$scope.age, cityAndstate:$scope.cityAndstate, email:$scope.email});
		//firstName = '';
	};

	$scope.customers = customers;
	$scope.firstName = customers.firstName;
	$scope.lastName = customers.lastName;
	$scope.age = customers.age;
	$scope.cityAndstate = customers.cityAndstate;
	$scope.email = customers.email;
	
	
  });