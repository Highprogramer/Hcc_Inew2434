package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class examServlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Servlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		RequestDispatcher dispatcher = request.getRequestDispatcher("/files.jsp");
		dispatcher.forward(request, response);
		PrintWriter out = response.getWriter();
		String form_sid = request.getParameter("search_id");
		String sql1 = "SELECT * from student";
		String sql2 = " where idstudent = ";
		String sql = "";
		if (form_sid.length() > 0) {
			sql = sql + sql1 + sql2 + form_sid;
		} else {
			sql = sql1;
		}
		System.out.println(form_sid);
		System.out.println(sql);
		out.println("<h1>Welcome </h1>");
		out.println("-----------------STUDENT INFO -----");
		/**
		 * 1. Create a Connection Object. 
		 * 2. Create a Statement 
		 * 3. Execute Query 
		 * 4. Result Set 
		 * 5. Loop through the result set 6. Send the info out with repsonse
		 * out
		 **/

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String connURL = "jdbc:mysql://localhost:3306/studentdb";
			String user = "root";
			String pwd = "";
			conn = DriverManager.getConnection(connURL, user, pwd);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			StringBuffer sb = new StringBuffer();
			sb.append("<table border='1'><th>St. No.</th><th>Student Name </th><th>address</th><th>City</th><th>zip</th><th>State</th></tr>");

			while (rs.next()) {
				sb.append("<tr><td>");
				String id = rs.getString("idstudent");
				sb.append(id);
				sb.append("</td><td>");
				String name = rs.getString("st_name");
				sb.append(name);
				sb.append("</td><td>");
				String address = rs.getString("st_address");
				sb.append(address);
				sb.append("</td><td>");
				String city = rs.getString("st_city");
				sb.append(city);
				sb.append("</td><td>");
				String zip = rs.getString("st_zip");
				sb.append(zip);
				sb.append("</td><td>");
				String state = rs.getString("st_state");
				sb.append(state);
				sb.append("</td></tr>");
			}
			sb.append("</table>");
			out.println(sb.toString());
		} catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			out.println("Ouch !! SOME THING BAD HAPPENED !");
			e.printStackTrace(out);
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace(out);
			}

		}
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
