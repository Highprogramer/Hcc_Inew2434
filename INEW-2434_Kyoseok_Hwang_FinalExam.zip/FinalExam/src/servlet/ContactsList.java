package servlet;

import java.util.ArrayList;

public class ContactsList {

	private static ArrayList<Contact> contactsList = null;
	
	public static ArrayList<Contact> getContactsList() {
		//if ((contactsList == null) && (contactsList.size() == 0)) {
		contactsList = new ArrayList<Contact>();
		contactsList.add(new Contact(1,"Raj","Joseph"));
		contactsList.add(new Contact(2,"Jose","Gonzales"));
		contactsList.add(new Contact(3,"Bob","Smith"));
		contactsList.add(new Contact(4,"Adrian","Shah"));
		contactsList.add(new Contact(5,"Kelly","Branco"));
		//}
		System.out.println("Contacts List ---->"+contactsList);
		return contactsList;
	}
	public static void setStudentsList(ArrayList<Contact> contactsList) {
		contactsList = ContactsList.contactsList;
	}

	

}
